NSE Option Chain Analyzer V9 - Android wrapper

This project packages the exact offline-safe HTML analyzer as an Android WebView app.
It reads uploaded NSE CSV files locally and does not require a server for the CSV analysis.

Build: Open this folder in Android Studio and Build > Generate App Bundle/APK > Generate APK.
The generated APK can then be installed on Android.

Note: Live NSE access can still depend on NSE/browser/network restrictions; the CSV analyzer is offline.
